# AeroDrive
Cab Booking System

HTML/CSS
A person can run this code on vs code by installing extensions for HTML/CSS and linking it by using pyscript.

AeroDrive.py
For executing this file properly, first install tkinter and connect it with SQLite database.
